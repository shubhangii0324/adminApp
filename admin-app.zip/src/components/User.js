import React, { useState, Fragment } from 'react';
import { Container, Row, Col, Table } from 'react-bootstrap';
import Input from '../components/UI/Input';
import Modal from '../components/UI/Modal';
import { useSelector, useDispatch } from 'react-redux';
import { addUser } from '../actions/user';
import {
  IoIosAdd,
  IoIosTrash
} from 'react-icons/io';

/**
* @author
* @function User
**/

const User = (props) => {

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [show, setShow] = useState(false);
  const [userDetailModal, setUserDetailModal] = useState(false);
  const [userDetails, setUserDetails] = useState(null);
  const createUser = useSelector(state => state.createUser);
  const dispatch = useDispatch();


  const handleClose = () => {

    const form = new FormData();
    form.append('firstName', firstName);
    form.append('lastName', lastName);
    form.append('email', email);

    dispatch(addUser(form));


    setShow(false);
  }
  const handleShow = () => setShow(true);

  const renderUsers = () => {
    return (
      <Table style={{ fontSize: 12 }} responsive="sm">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {
            createUser.users.length > 0 ?
              createUser.users.map(user =>
                <tr onClick={() => showUserDetailsModal(user)} key={user._id}>
                  <td>{user.firstName}</td>
                  <td>{user.lastName}</td>
                  <td>{user.email}</td>
                </tr>
              ) : null
          }

        </tbody>
      </Table>
    );
  }

  const renderAddUserModal = () => {
    return (
      <Modal
        show={show}
        handleClose={handleClose}
        modalTitle={'Add New User'}
      >
        <Input
          label="First Name"
          value={firstName}
          placeholder={`First Name`}
          onChange={(e) => setFirstName(e.target.value)}
        />
        <Input
          label="last Name"
          value={lastName}
          placeholder={`Last Name`}
          onChange={(e) => setLastName(e.target.value)}
        />
        <Input
          label="email"
          value={email}
          placeholder={`email`}
          onChange={(e) => setEmail(e.target.value)}
        />
      </Modal>
    );
  }

  const handleCloseUserDetailsModal = () => {
    setUserDetailModal(false);
  }
  
  const showUserDetailsModal = (product) => {
    setUserDetails(product);
    setUserDetailModal(true);
  }

  const renderUserDetailsModal = () => {

    if(!userDetails){
      return null;
    }

    return (
      <Modal
        show={userDetailModal}
        handleClose={handleCloseUserDetailsModal}
        modalTitle={'User Details'}
        size="lg"
      >

        <Row>
          <Col md="6">
            <label className="key">First Name</label>
            <p className="value">{userDetails.firstName}</p>
          </Col>
          <Col md="6">
            <label className="key">Last Name</label>
            <p className="value">{userDetails.lastName}</p>
          </Col>
        </Row>
        <Row>
          <Col md="6">
            <label className="key">email</label>
            <p className="value">{userDetails.email}</p>
          </Col>
        </Row>

      </Modal>
    );
  }
  return (
    <Fragment>
      <Container>
        <Row>
          <Col md={12}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <h3>Admins</h3>
              <button onClick={handleShow}><IoIosAdd /> <span>Add</span></button>
            </div>

          </Col>
        </Row>
        <Row>
          <Col>
            {renderUsers()}
          </Col>
        </Row>
      </Container>
      {renderAddUserModal()}
      {renderUserDetailsModal()}

      </Fragment>
  )

}

export default User