import React, { useState, Fragment } from 'react';
import { Container, Row, Col, Table } from 'react-bootstrap';
import Input from '../UI/Input';
import Modal from '../UI/Modal';
import { useSelector, useDispatch } from 'react-redux';
import { addTaxes } from '../../actions';
import {
  IoIosAdd
} from 'react-icons/io';

/**
* @author
* @function Taxes
**/

const Taxes = (props) => {

  const [name, setName] = useState('');
  const [rate, setRate] = useState('');
  const [price, setPrice] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [show, setShow] = useState(false);
  const [taxDetailModal, setTaxDetailModal] = useState(false);
  const [taxDetails, setTaxDetails] = useState(null);
  const category = useSelector(state => state.category);
  const tax = useSelector(state => state.tax);
  const dispatch = useDispatch();


  const handleClose = () => {

    const form = new FormData();
    form.append('name', name);
    form.append('rate', rate);
    form.append('price', price);
    form.append('category', categoryId);


    dispatch(addTaxes(form));


    setShow(false);
  }
  const handleShow = () => setShow(true);

  const createCategoryList = (categories, options = []) => {

    for (let category of categories) {
      options.push({ value: category._id, name: category.name });
      if (category.children.length > 0) {
        createCategoryList(category.children, options)
      }
    }

    return options;
  }


  const renderTaxes = () => {
    return (
      <Table style={{ fontSize: 12 }} responsive="sm">
        <thead>
          <tr>
            <th>Name</th>
            <th>Rate</th>
            <th>Price</th>
          </tr>
        </thead>
        <tbody>
          {
            tax.taxes.length > 0 ?
              tax.taxes.map(product =>
                <tr onClick={() => showTaxDetailsModal(tax)} key={tax._id}>
                  <td>{tax.name}</td>
                  <td>{tax.rate}</td>
                  <td>{tax.price}</td>
                </tr>
              ) : null
          }

        </tbody>
      </Table>
    );
  }

  const renderAddTaxModal = () => {
    return (
      <Modal
        show={show}
        handleClose={handleClose}
        modalTitle={'Add New Tax'}
      >
        <Input
          label="Name"
          value={name}
          placeholder={`Name`}
          onChange={(e) => setName(e.target.value)}
        />
        <Input
          label="Rate"
          value={rate}
          placeholder={`Rate(%)`}
          onChange={(e) => setRate(e.target.value)}
        />
        <Input
          label="Price"
          value={price}
          placeholder={`Price`}
          onChange={(e) => setPrice(e.target.value)}
        />
        <select
          className="form-control"
          value={categoryId}
          onChange={(e) => setCategoryId(e.target.value)}>
          <option>select category</option>
          {
            createCategoryList(category.categories).map(option =>
              <option key={option.value} value={option.value}>{option.name}</option>)
          }
        </select>
      </Modal>
    );
  }

  const handleCloseTaxDetailsModal = () => {
    setTaxDetailModal(false);
  }
  
  const showTaxDetailsModal = (tax) => {
    setTaxDetails(tax);
    setTaxDetailModal(true);
  }

  const renderTaxDetailsModal = () => {

    if(!taxDetails){
      return null;
    }

    return (
      <Modal
        show={taxDetailModal}
        handleClose={handleCloseTaxDetailsModal}
        modalTitle={`Tax Details`}
        size="lg"
      >

        <Row>
          <Col md="6">
            <label className="key">Name</label>
            <p className="value">{taxDetails.name}</p>
          </Col>
          <Col md="6">
            <label className="key">Rate</label>
            <p className="value">{taxDetails.rate}</p>
          </Col>
          <Col md="6">
            <label className="key">Price</label>
            <p className="value">{taxDetails.price}</p>
          </Col>
        </Row>

      </Modal>
    );
  }
  return (
    <Fragment>
      <Container>
        <Row>
          <Col md={12}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <h3>Taxes</h3>
              <button onClick={handleShow}><IoIosAdd /> <span>Add</span></button>
            </div>

          </Col>
        </Row>
        <Row>
          <Col>
            {renderTaxes()}
          </Col>
        </Row>
      </Container>
      {renderAddTaxModal()}
      {renderTaxDetailsModal()}

      </Fragment>
  )

}

export default Taxes