import React, { useState, Fragment } from 'react';
import { Container, Row, Col, Table } from 'react-bootstrap';
import Input from '../components/UI/Input';
import Modal from '../components/UI/Modal';
import { useSelector, useDispatch } from 'react-redux';
import { addCoupons } from '../actions/coupons.actions';
import {
  IoIosAdd,
  IoIosTrash
} from 'react-icons/io';

/**
* @author
* @function Coupons
**/

const Coupons = (props) => {

  const [name, setName] = useState('');
  const [rate, setRate] = useState('');
  const [price, setPrice] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [show, setShow] = useState(false);
  const [couponDetailsModal, setCouponDetailsModal] = useState(false);
  const [couponDetails, setCouponDetails] = useState(null);
  const category = useSelector(state => state.category);
  const coupons = useSelector(state => state.coupons);
  const dispatch = useDispatch();


  const handleClose = () => {

    const form = new FormData();
    form.append('name', name);
    form.append('rate', rate);
    form.append('price', price);
    form.append('category', categoryId);

    dispatch(addCoupons(form))


    setShow(false);
  }
  const handleShow = () => setShow(true);

  const createCategoryList = (categories, options = []) => {

    for (let category of categories) {
      options.push({ value: category._id, name: category.name });
      if (category.children.length > 0) {
        createCategoryList(category.children, options)
      }
    }

    return options;
  }

  const renderCoupons = () => {
    return (
      <Table style={{ fontSize: 12 }} responsive="sm">
        <thead>
          <tr>
            <th>Name</th>
            <th>Rate</th>
            <th>Price</th>
            <th>Category</th>
          </tr>
        </thead>
        <tbody>
          {
            coupons.coupons.length > 0 ?
              coupons.coupons.map(coupon =>
                <tr onClick={() => showCouponDetailsModal(coupon)} key={coupon._id}>
                  <td>{coupon.name}</td>
                  <td>{coupon.rate}</td>
                  <td>{coupon.price}</td>
                  <td>{coupon.category.name}</td>
                </tr>
              ) : null
          }

        </tbody>
      </Table>
    );
  }

  const renderAddCouponModal = () => {
    return (
      <Modal
        show={show}
        handleClose={handleClose}
        modalTitle={'Add New Coupon'}
      >
        <Input
          label="Name"
          value={name}
          placeholder={`Coupon Name`}
          onChange={(e) => setName(e.target.value)}
        />
        <Input
          label="Rate"
          value={rate}
          placeholder={`Rate`}
          onChange={(e) => setRate(e.target.value)}
        />
        <Input
          label="Price"
          value={price}
          placeholder={`Price`}
          onChange={(e) => setPrice(e.target.value)}
        />
        <select
          className="form-control"
          value={categoryId}
          onChange={(e) => setCategoryId(e.target.value)}>
          <option>select category</option>
          {
            createCategoryList(category.categories).map(option =>
              <option key={option.value} value={option.value}>{option.name}</option>)
          }
        </select>
      </Modal>
    );
  }

  const handleCloseCouponDetailsModal = () => {
    setCouponDetailsModal(false);
  }
  
  const showCouponDetailsModal = (coupons) => {
    setCouponDetails(coupons)
    setCouponDetailsModal(true)
  }

  const renderCouponDetailsModal = () => {

    if(!couponDetails){
      return null;
    }

    return (
      <Modal
        show={couponDetailsModal}
        handleClose={handleCloseCouponDetailsModal}
        modalTitle={'Coupon Details'}
        size="lg"
      >

        <Row>
          <Col md="6">
            <label className="key">Name</label>
            <p className="value">{couponDetails.name}</p>
          </Col>
          <Col md="6">
            <label className="key">Rate</label>
            <p className="value">{couponDetails.rate}</p>
          </Col>
        </Row>
        <Row>
          <Col md="6">
            <label className="key">Price</label>
            <p className="value">{couponDetails.price}</p>
          </Col>
          <Col md="6">
            <label className="key">Category</label>
            <p className="value">{couponDetails.category.name}</p>
          </Col>
        </Row>

      </Modal>
    );
  }
  return (
    <Fragment>
      <Container>
        <Row>
          <Col md={12}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <h3>Coupons</h3>
              <button onClick={handleShow}><IoIosAdd /> <span>Add</span></button>
            </div>

          </Col>
        </Row>
        <Row>
          <Col>
            {renderCoupons()}
          </Col>
        </Row>
      </Container>
      {renderAddCouponModal()}
      {renderCouponDetailsModal()}

      </Fragment>
  )

}

export default Coupons