import React, { useState, Fragment } from 'react';
import { Container, Row, Col, Table } from 'react-bootstrap';
import Breadcrumb from '../common/breadcrumb';
import data from '../../assets/data/physical_list';
import { Edit, Trash2 } from 'react-feather'
import Input from '../UI/Input';
import Modal from '../UI/Modal';
import { useSelector, useDispatch } from 'react-redux';
import { generatePublicUrl } from '../../UrlConfig';
import {
  IoIosAdd,
  IoIosTrash
} from 'react-icons/io';


/**
* @author
* @function Products
**/

const Products = (props) => {

  const [show, setShow] = useState(false);
  const [productDetailModal, setProductDetailModal] = useState(false);
  const [productDetails, setProductDetails] = useState(null);
  const category = useSelector(state => state.category);
  const product = useSelector(state => state.product);




  const renderProducts = () => {
    return (
      <div className="row products-admin ratio_asos">
          {
            product.products.length > 0 ?
              product.products.map(product =>
                  <div className="col-xl-3 col-sm-6" key={product._id}>
                      <div className="card">
                          <div className="products-admin">
                              <div className="card-body product-box">
                                  <div className="img-wrapper">
                                      <div className="front">
                                          <a className="bg-size">
                                          {product.productPictures.map(picture => 
                                              <img className="img-fluid blur-up bg-img lazyloaded" src={generatePublicUrl(picture.img)} /> 
                                          )}
                                         </a>
                                          <div className="product-hover">
                                              <ul>
                                                  <li>
                                                      <button className="btn" type="button">
                                                          <Edit className="editBtn" />
                                                      </button>
                                                  </li>
                                                  <li>
                                                      <button className="btn" type="button">
                                                          <Trash2 className="deleteBtn" />
                                                      </button>
                                                  </li>
                                              </ul>
                                          </div>
                                      </div>
                                  </div>
                                  <div className="product-detail">
                                      <div className="rating">
                                          <i className="fa fa-star"></i>
                                          <i className="fa fa-star"></i>
                                          <i className="fa fa-star"></i>
                                          <i className="fa fa-star"></i>
                                          <i className="fa fa-star"></i>
                                      </div>
                                      <a> <h6>{product.name}</h6></a>
                                      <h4>{product.price} <del >{product.price}</del></h4>
                                      <ul className="color-variant">
                                          <li className="bg-light0"></li>
                                          <li className="bg-light1"></li>
                                          <li className="bg-light2"></li>
                                      </ul>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              ) : null
              
          }
          </div>
          );
      }

  return (
    <Fragment>
      <Breadcrumb title="Product List" parent="Products" />
      <div className="container-fluid">
        {renderProducts()}
      </div>

      </Fragment>
  )

}

export default Products