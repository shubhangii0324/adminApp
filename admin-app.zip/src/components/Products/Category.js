import React, { Fragment, useEffect, useState } from 'react'
import Breadcrumb from '../common/breadcrumb';
import {Modal, Table, Carousel, Row, Col} from 'react-bootstrap';
import 'react-toastify/dist/ReactToastify.css';
import { useDispatch, useSelector } from 'react-redux';
import { getAllCategory, addCategory } from '../../actions/category.actions';
import Datatable from '../common/datatable';
import Input from '../UI/Input';
import CheckboxTree from 'react-checkbox-tree';
import 'react-checkbox-tree/lib/react-checkbox-tree.css';
import {
    IoIosCheckboxOutline,
    IoIosCheckbox,
    IoIosArrowForward,
    IoIosArrowDown,
    IoIosAdd,
    IoIosTrash,
    IoIosCloudUpload
} from 'react-icons/io';


/**
* @author
* @function Category
**/

const Category = (props) => {

    const category = useSelector(state => state.category);
    const [categoryName, setCategoryName] = useState('');
    const [parentCategoryId, setParentCategoryId] = useState(''); 
    const [categoryImage, setCategoryImage] = useState('');
    const [show, setShow] = useState(false);
    const [checked, setChecked] = useState([]);
    const [expanded, setExpanded] = useState([]);

    const dispatch = useDispatch();

    useEffect(() => {
        dispatch(getAllCategory());
    }, []);

    const handleClose = () => {

        const form = new FormData();

        if (categoryName === "") {
            alert('Category name is required');
            setShow(false);
            return;
        }

        form.append('name', categoryName);
        form.append('parentId', parentCategoryId);
        form.append('categoryImage', categoryImage);
        dispatch(addCategory(form));
        setCategoryName('');
        setParentCategoryId('');
        setShow(false);
    }
    const handleShow = () => setShow(true);

    const renderCategories = (categories) => {
        let myCategories = [];
        for(let category of categories) {
            myCategories.push(
            {
                label: category.name,
                value: category._id,
                children: category.children.length > 0 && renderCategories(category.children)
            }
            );
        }
        return myCategories;
    }

    const createCategoryList = (categories, options = []) => {
        for (let category of categories) {
            options.push({
                value: category._id,
                name: category.name,
                parentId: category.parentId,
                type: category.type
            });
            if (category.children.length > 0) {
                createCategoryList(category.children, options)
            }
        }

        return options;
    }

    const handleCategoryImage = (e) => {
        setCategoryImage(e.target.files[0]);
    }


  return(
      <Fragment>
          <Breadcrumb title="Category" parent="Category" />
          <div className="container-fluid">
              <div className="row">
                  <div className="col-sm-12">
                      <div className="card">
                          <div className="card-header">   
                            <h5>Products Category</h5>
                          </div>
                          <div className="card-body">
                              <div className="btn-popup pull-right">
                              <button type="button" className="btn btn-primary" data-toggle="modal" data-original-title="test" data-target="#exampleModal" onClick={handleShow}>Add Category</button>
                              
                              <Modal show={show} onHide={handleClose} >
                                  <Modal.Header closeButton>
                                      <Modal.Title>
                                          Add Category
                                      </Modal.Title>
                                  </Modal.Header>
                                            <div className="modal-body">
                                                <label htmlFor="recipient-name" className="col-form-label" >Category Name :</label>
                                                <Input
                                                    value={categoryName}
                                                    placeholder={'Category Name'}
                                                    onChange={(e) => setCategoryName(e.target.value)}
                                                />
                                                <select
                                                    value={parentCategoryId}
                                                    onChange={(e) => setParentCategoryId(e.target.value)}
                                                    className="form-control"
                                                    id="validationCustom02">
                                                    <option>Select Category</option>
                                                    {
                                                        createCategoryList(category.categories).map(option =>
                                                            <option key={option.value} value={option.value}>{option.name}</option>)
                                                    }
                                                </select>
                                                <label htmlFor="recipient-name" className="col-form-label" >Category Image :</label>
                                                <input className="form-control" id="validationCustom02" type="file" name="categoryImage" onChange={handleCategoryImage} />
                                            </div>
                                            <div className="modal-footer">
                                                <button type="button" className="btn btn-primary" onClick={handleClose}>Save</button>
                                            </div>
                                        </Modal>

                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div className="clearfix"></div>
              
            <div id="basicScenario" className="product-physical">
            <Row>
                    <Col md={12}>
                        <CheckboxTree
                            nodes={renderCategories(category.categories)}
                            checked={checked}
                            expanded={expanded}
                            onCheck={checked => setChecked(checked)}
                            onExpand={expanded => setExpanded(expanded)}
                            icons={{
                                check: <IoIosCheckbox />,
                                uncheck: <IoIosCheckboxOutline />,
                                halfCheck: <IoIosCheckboxOutline />,
                                expandClose: <IoIosArrowForward />,
                                expandOpen: <IoIosArrowDown />
                            }}
                        />
                    </Col>
                </Row>
            </div>
          </div>

      </Fragment>
   )

 }

export default Category