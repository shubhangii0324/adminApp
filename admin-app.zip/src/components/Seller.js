import React, { useState, Fragment } from 'react';
import { Container, Row, Col, Table } from 'react-bootstrap';
import Input from '../components/UI/Input';
import Modal from '../components/UI/Modal';
import { useSelector, useDispatch } from 'react-redux';
import { addSeller } from '../actions/seller.actions';
import {
  IoIosAdd,
  IoIosTrash
} from 'react-icons/io';

/**
* @author
* @function Seller
**/

const Seller = (props) => {

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [show, setShow] = useState(false);
  const [sellerDetailModal, setSellerDetailModal] = useState(false);
  const [sellerDetails, setSellerDetails] = useState(null);
  const seller = useSelector(state => state.seller);
  const dispatch = useDispatch();


  const handleClose = () => {

    const form = new FormData();
    form.append('firstName', firstName);
    form.append('lastName', lastName);
    form.append('email', email);

    dispatch(addSeller(form));


    setShow(false);
  }
  const handleShow = () => setShow(true);

  const renderSellers = () => {
    return (
      <Table style={{ fontSize: 12 }} responsive="sm">
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {
            seller.sellers.length > 0 ?
              seller.sellers.map(user =>
                <tr onClick={() => showSellerDetailsModal(seller)} key={seller._id}>
                  <td>{seller.firstName}</td>
                  <td>{seller.lastName}</td>
                  <td>{seller.email}</td>
                </tr>
              ) : null
          }

        </tbody>
      </Table>
    );
  }

  const renderAddSellerModal = () => {
    return (
      <Modal
        show={show}
        handleClose={handleClose}
        modalTitle={'Add New Seller'}
      >
        <Input
          label="First Name"
          value={firstName}
          placeholder={`First Name`}
          onChange={(e) => setFirstName(e.target.value)}
        />
        <Input
          label="last Name"
          value={lastName}
          placeholder={`Last Name`}
          onChange={(e) => setLastName(e.target.value)}
        />
        <Input
          label="email"
          value={email}
          placeholder={`email`}
          onChange={(e) => setEmail(e.target.value)}
        />
      </Modal>
    );
  }

  const handleCloseSellerDetailsModal = () => {
    setSellerDetailModal(false);
  }
  
  const showSellerDetailsModal = (product) => {
    setSellerDetails(product);
    setSellerDetailModal(true);
  }

  const renderSellerDetailsModal = () => {

    if(!sellerDetails){
      return null;
    }

    return (
      <Modal
        show={sellerDetailModal}
        handleClose={handleCloseSellerDetailsModal}
        modalTitle={'Seller Details'}
        size="lg"
      >

        <Row>
          <Col md="6">
            <label className="key">First Name</label>
            <p className="value">{sellerDetails.firstName}</p>
          </Col>
          <Col md="6">
            <label className="key">Last Name</label>
            <p className="value">{sellerDetails.lastName}</p>
          </Col>
        </Row>
        <Row>
          <Col md="6">
            <label className="key">email</label>
            <p className="value">{sellerDetails.email}</p>
          </Col>
        </Row>

      </Modal>
    );
  }
  return (
    <Fragment>
      <Container>
        <Row>
          <Col md={12}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <h3>Sellers</h3>
              <button onClick={handleShow}><IoIosAdd /> <span>Add</span></button>
            </div>

          </Col>
        </Row>
        <Row>
          <Col>
            {renderSellers()}
          </Col>
        </Row>
      </Container>
      {renderAddSellerModal()}
      {renderSellerDetailsModal()}

      </Fragment>
  )

}

export default Seller