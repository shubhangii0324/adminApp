export const api = 'https://ecomm007backend.herokuapp.com/api';
export const generatePublicUrl = (fileName) => {
    return `https://ecomm007backend.herokuapp.com/public/${fileName}`;
}